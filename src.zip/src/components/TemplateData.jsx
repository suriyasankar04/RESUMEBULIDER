

export const TemplateDate = [
    {
        Image:"https://cdn-images.zety.com/templates/zety/valera-11-classic-silver-dark-332@2x.png",
        tid:"1"
    },
    {
        Image:"https://marketplace.canva.com/EAFRuCp3DcY/1/0/566w/canva-black-white-minimalist-cv-resume-swrqd3VWKmc.jpg",
        tid:"2"
    },
    {
        Image:"https://marketplace.canva.com/EAFYHVf4VeM/1/0/566w/canva-professional-cv-resume-gBa6Pme5mIA.jpg",
        tid:"3"
    },
    {
        Image:"https://cdn-images.zety.com/templates/zety/influx-8-duo-silver-dark-971@3x.png",
        tid:"4"
    },
    {
        Image:"https://s3.amazonaws.com/thumbnails.venngage.com/template/2d6cc4d6-6ffc-4e10-a197-76ea1209aa54.png",
        tid:"5"
    },
    {
        Image:"https://app.resumekraft.com/assets/img/8.jpg",
        tid:"6"
    }
];
