import React from 'react'
import Header from '../Header/Header'
import Sidebar from '../SideBar/SideBar'
import { Link } from 'react-router-dom'
import insta from './asserts/instagram.svg'
import twitter from './asserts/twitter.svg'
import github from './asserts/github.svg'
import youtube from './asserts/youtube.svg'
import linkedin from './asserts/linkedin.svg'
import { useNavigate } from 'react-router-dom'
// import "../css/Landing.css"
import Footer from '../Header/Footer'
import "../css/Home.css"

export default function Home() {
    const [openSidebarToggle, setOpenSidebarToggle] = React.useState(false)
    const navigate = useNavigate();
    const Token = localStorage.getItem('token') == null
    const OpenSidebar = () => {
      setOpenSidebarToggle(!openSidebarToggle)
    }
    const handleClick=()=>{
      if(!Token){
        navigate("/create");
      }
      else{
        navigate("/login");
      }
    }
    const handleLogout =() =>{
      localStorage.clear();
      navigate("/home")
    }
  return (
    <div className='home_css'>
{/* <Header openSidebarToggle={openSidebarToggle} OpenSidebar={OpenSidebar}/> */}
    {/* <div className='lan'>HOME</div>
     */}
     <div class='hero-section'>
<div className='home_navbar'>
  <div className='home_logo'>RESUME FUSION</div>
  <div className='home_menu'>
    
  <Link to="/" class='menu_item'>HOME</Link>
    <Link to="" class='menu_item'>ABOUT</Link>
    {Token ?(
<div>

      <Link to="/login" class='menu_item'>LOGIN</Link>
      </div>
    ):(
      <div>
  <Link to="/" onClick={handleLogout}class='menu_item'>LOGOUT</Link>
  </div>
    )}


  </div>
</div>
       <div class='hero-text'>
         <h1 className='hero-sec'>Create your perfect resume online today</h1>
         <p className='hero-sec'>Build a professional resume and so on</p>
         <button className='btn-3' onClick={handleClick}><span>
          CREATE
          </span>
          </button>
       </div>
     
</div>
<section class="U_section_layout10">
  <div class="U_padding-global">
    <div class="U_container-large">
      <div class="U_padding-section-large">
        <div class="U_layout10_component src-component_renderer-component_renderer__twoByTwoGrid">
          <div class="U_layout10_content">
            <div class="U_layout10_content1">
            <div class="U_margin-bottom U_margin-xsmall">
              <div class="U_text-weight-semibold">Create</div>
              </div><div class="U_margin-bottom U_margin-small">
                <h2 class="home_text1">Choose from Professional Resume Templates</h2>
                </div><div class="U_margin-bottom U_margin-medium">
                  <p class="U_text-size-medium">Our online resume builder offers a wide variety of professional designs for you to choose from. Create a standout resume that will impress employers.</p>
                  </div>
                  <div class="U_layout10_item-list src-component_renderer-component_renderer__twoByTwoGrid">
                    <div class="U_layout10_item">
                      <div class="U_margin-bottom U_margin-xsmall">
                        <img src="https://library.relume.io/__assets/624380709031623bfe4aee60/624380709031626fc14aee84_icon.svg" loading="lazy" width="auto" height="auto" alt="__wf_reserved_inherit" class="U_icon-1x1-medium"/>
                        </div>
                        <div class="U_margin-bottom U_margin-xsmall">
                          <h6 class="home_text2">Variety</h6>
                          </div>
                          <p class="">Select from a range of beautifully designed templates to suit your industry.</p>
                          </div><div class="U_layout10_item">
                            <div class="U_margin-bottom U_margin-xsmall">
                              <img src="https://library.relume.io/__assets/624380709031623bfe4aee60/624380709031626fc14aee84_icon.svg" loading="lazy" width="auto" height="auto" alt="__wf_reserved_inherit" class="U_icon-1x1-medium"/></div><div class="U_margin-bottom U_margin-xsmall"><h6 class="">Customize</h6>
                              </div>
                              <p class="">Personalize your resume with your own information and make it unique.</p>
                              </div>
                              </div>
                              <div class="U_margin-top U_margin-medium">
                                <div class="U_button-group">
                                  <a tabindex="-1" class="U_button U_is-secondary src-component_renderer-webflow_base__w-button src-component_renderer-component_renderer__resetCursor">Get Started</a>
                                  <a tabindex="-1" class="U_button U_is-link U_is-icon src-component_renderer-webflow_base__w-inline-block src-component_renderer-component_renderer__resetCursor">Learn More
                                    {/* <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M6 3L11 8L6 13" stroke="CurrentColor" stroke-width="1.5"></path>
</svg> */}
</a>
                                  <div class="U_icon-embed-xxsmall">
</div>
</div>
</div>
</div>
<div class="U_layout10_image-wrapper">
  <img src="https://library.relume.io/__assets/624380709031623bfe4aee60/6243807090316203124aee66_placeholder-image.svg" loading="lazy" width="auto" height="auto" alt="__wf_reserved_inherit" class="U_layout10_image"/>
  </div>
</div>
  </div>
  </div></div></div></section>
  <section class="U_section_blog42">
    <div class="U_padding-global">
      <div class="U_container-large1">
        <div class="U_padding-section-large">
          <div class="U_blog42_component">
            <div class="U_margin-bottom U_margin-xxlarge">
              <div class="U_blog42_heading-wrapper">
                <div class="U_blog42_heading">
                  <div class="U_max-width-large">
                    <div class="U_margin-bottom U_margin-xsmall">
                      <div class="U_text-weight-semibold">Resume</div>
                      </div>
                      <div class="U_margin-bottom U_margin-xsmall">
                        <h2 class="home_text1">Stay Ahead in Your Career</h2>
                        </div>
                        <p class="U_text-size-medium">Discover the latest tips and advice for resume building, job hunting, and career development.</p>
                        </div>
                        </div>
                        <div class="U_blog42_button-row_U_hide-mobile-landscape">
                          <a tabindex="-1" class="U_button U_is-secondary src-component_renderer-webflow_base__w-button src-component_renderer-component_renderer__resetCursor">Explore More</a>
                          </div>
                          </div>
                          </div>
                          <div class="U_blog42_list-wrapper">
                            <div class="U_blog42_list_src-component_renderer-component_renderer__twoByTwoGrid">
                              <div class="U_blog42_item">
                                {/* <a tabindex="-1" class="U_blog42_image-link src-component_renderer-webflow_base__w-inline-block src-component_renderer-component_renderer__resetCursor"> */}
                                <div class="U_blog42_image-wrapper">
                                  <img height="auto" loading="lazy" width="auto" src="https://library.relume.io/__assets/624380709031623bfe4aee60/6243807090316262904aee69_Placeholder%20Image%20-%20Landscape.svg" alt="__wf_reserved_inherit" class="U_blog42_image"/>
                                  </div>
                                  {/* </a> */}
                                  <br></br>
                                  <div class="U_blog42_meta-wrapper">
                                    <a tabindex="-1" class="U_blog42_category-link src-component_renderer-webflow_base__w-inline-block src-component_renderer-component_renderer__resetCursor">
                                    <div class="U_resume">Resume
                                    <div class="U_5min">5 min read</div>
                                    </div>
                                    </a>
                                    </div>
                                    <a tabindex="-1" class="U_blog42_title-link src-component_renderer-webflow_base__w-inline-block src-component_renderer-component_renderer__resetCursor">
                                      </a>
                                      <h3 class="U_heading-style-h5">Mastering the Art of Resume Writing</h3>
                                      <div class="U_text-size-regular">Learn how to craft a compelling resume that stands out to employers.</div>
                                      {/* <div class="U_blog42_button-wrapper"> */}
                                        <a tabindex="-1" class="U_button U_is-link U_is-icon src-component_renderer-webflow_base__w-inline-block src-component_renderer-component_renderer__resetCursor">
                                          <div class="">Read More</div>
                                          {/* <div class="U_icon-embed-xxsmall">
                                            <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                <path d="M6 3L11 8L6 13" stroke="CurrentColor" stroke-width="1.5"></path>
                                              </svg>
                                          </div> */}
</a>
{/* </div> */}
</div>
<div class="U_blog42_item">
  <a tabindex="-1" class="U_blog42_image-link src-component_renderer-webflow_base__w-inline-block src-component_renderer-component_renderer__resetCursor">
  <div class="U_blog42_image-wrapper">
    <img height="auto" loading="lazy" width="auto" src="https://library.relume.io/__assets/624380709031623bfe4aee60/6243807090316262904aee69_Placeholder%20Image%20-%20Landscape.svg" alt="__wf_reserved_inherit" class="U_blog42_image"/>
    </div>
    </a>
    <br></br>
    <div class="U_blog42_meta-wrapper">
    <a tabindex="-1" class="U_blog42_category-link src-component_renderer-webflow_base__w-inline-block src-component_renderer-component_renderer__resetCursor">
      <div class="U_resume">Resume
      
      <div class="U_5min">5 min read</div>
      </div>
      </a>
      </div><a tabindex="-1" class="U_blog42_title-link src-component_renderer-webflow_base__w-inline-block src-component_renderer-component_renderer__resetCursor">
        <h3 class="U_heading-style-h5">Job Hunting Strategies for Success</h3>
        </a>
        <div class="U_text-size-regular">Discover effective strategies to land your dream job.</div>
        {/* <div class="U_blog42_button-wrapper"> */}
        <br></br>
          <a tabindex="-1" class="U_button U_is-link U_is-icon src-component_renderer-webflow_base__w-inline-block src-component_renderer-component_renderer__resetCursor">
            <div class="">Read More</div><div class="U_icon-embed-xxsmall">
              {/* <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M6 3L11 8L6 13" stroke="CurrentColor" stroke-width="1.5"></path>
</svg> */}
</div>
</a>
{/* </div> */}
</div>
<div class="U_blog42_item">
  <a tabindex="-1" class="U_blog42_image-link src-component_renderer-webflow_base__w-inline-block src-component_renderer-component_renderer__resetCursor">
    <div class="U_blog42_image-wrapper">
      <img height="auto" loading="lazy" width="auto" src="https://library.relume.io/__assets/624380709031623bfe4aee60/6243807090316262904aee69_Placeholder%20Image%20-%20Landscape.svg" alt="__wf_reserved_inherit" class="U_blog42_image"/>
      </div>
      </a>
      <br></br>
      <div class="U_blog42_meta-wrapper">
        <a tabindex="-1" class="U_blog42_category-link src-component_renderer-webflow_base__w-inline-block src-component_renderer-component_renderer__resetCursor">
          <div class="U_resume">Resume
          
          <div class="U_5min">5 min read</div>
          </div>
          </a>
          </div>
          <a tabindex="-1" class="U_blog42_title-link src-component_renderer-webflow_base__w-inline-block src-component_renderer-component_renderer__resetCursor">
            <h3 class="U_heading-style-h5">Advancing Your Career: Tips and Advice</h3>
            </a>
            <div class="U_text-size-regular">Learn how to take your career to the next level.</div>
            {/* <div class="U_blog42_button-wrapper"> */}
            <br></br>
              <a tabindex="-1" class="U_button U_is-link U_is-icon src-component_renderer-webflow_base__w-inline-block src-component_renderer-component_renderer__resetCursor">
                <div class="">Read More</div>
                {/* <div class="U_icon-embed-xxsmall"><svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M6 3L11 8L6 13" stroke="CurrentColor" stroke-width="1.5">
</path>
</svg>
</div> */}
</a>
{/* </div> */}
</div>
</div>
</div>
<div class="U_blog42_button-row U_show-mobile-landscape">
  <a tabindex="-1" class="U_button U_is-secondary src-component_renderer-webflow_base__w-button src-component_renderer-component_renderer__resetCursor">Explore All</a></div></div></div></div></div></section>
   



    <Footer/>

    {/* <footer>
            <div class="footer-line"></div>
            <div class="footer-wrapper">
                <section class="footer-top">
                    <div class="footer-headline">
                        <h3 className='footerline'>Sign up to our newsletter</h3>
                        <p>
                            Stay up to date with our news and articles
                        </p>
                    </div>
                    <div class="footer-subscribe">
                        <input type="email" spellcheck="false" placeholder="Your Email"/>
                        <button>
                            Sign Up
                        </button>
                    </div>
                </section>
                <div class="footer-columns">
                    <section class="footer-logo">
                        <svg xmlns="http://www.w3.org/2000/svg" class="logo"
                             fill="none" viewBox="30 30 126 126"
                        >
                            <path d="M82.646 37.0917C85.7401 35.3054 89.552 35.3054 92.646 37.0917L133.614 60.7445L105.286 77.3318C100.901 72.9296 94.8325 70.2051 88.128 70.2051C81.1554 70.2051 74.871 73.1519 70.4523 77.8681L41.4416 60.8811L82.646 37.0917Z" fill="white"></path>
                            <path d="M64.9303 87.4484L35.9141 70.4582V117.952L64.8222 101.025C64.2287 98.9258 63.9111 96.7109 63.9111 94.4219C63.9111 91.9977 64.2673 89.6567 64.9303 87.4484Z" fill="white"></path>
                            <path d="M70.1924 110.694L41.8975 127.262L82.646 150.788C85.74 152.574 89.552 152.574 92.646 150.788L133.158 127.398L105.556 111.236C101.152 115.8 94.9714 118.639 88.128 118.639C81.0175 118.639 74.6227 115.574 70.1924 110.694Z" fill="white"></path>
                            <path d="M111.22 101.739L139.376 118.226C139.377 118.162 139.378 118.098 139.378 118.034V70.1831L111.101 86.7403C111.908 89.154 112.345 91.7369 112.345 94.4219C112.345 96.9723 111.951 99.4305 111.22 101.739Z" fill="white"></path>
                        </svg>
                        <h2 class="hide">Astra</h2>
                    </section>
                    <section>
                        <h3>Product</h3>
                        <div className='footsec'>
                           
                                <a href="#" title="API">API</a>
                            
                            <br></br>
                                <a href="#" title="Pricing">Pricing</a>
                           
                          <br></br>
                                <a href="#" title="Documentation">Documentation</a>
                         <br></br>
                         
                                <a href="#" title="Release Notes">Release Notes</a>
                          
                          <br></br>
                                <a href="#" title="Status">Status</a>
                          
                        </div>
                    </section>
                    <section>
                        <h3>Resources</h3>
                        <ul className='footsec'>
                            
                                <a href="#" title="Support">Support</a>
                           <br></br>
                                <a href="#" title="Sitemap">Sitemap</a>
                            <br></br>
                                <a href="#" title="Newsletter">Newsletter</a>
                            <br></br>
                                <a href="#" title="Help Centre">Help Centre</a>
                           <br></br>
                                <a href="#" title="Investor">Investor</a>
                           <br></br>
                        </ul>
                    </section>
                    <section>
                        <h3>Company</h3>
                        <ul className='footsec'>
                           
                                <a href="#" title="About Us">About Us</a>
                          <br></br>
                                <a href="#" title="Blog">Blog</a>
                           <br></br>
                                <a href="#" title="Careers">Careers</a>
                           <br></br>
                                <a href="#" title="Press">Press</a>
                           <br></br>
                                <a href="#" title="Contact">Contact</a>
                           
                        </ul>
                    </section>
                    <section>
                        <h3>Legal</h3>
                        <ul className='footsec'>
                           
                                <a href="#" title="Terms and services">
                                    Terms
                                </a>
                            <br></br>
                                <a href="#" title="Privacy Policy">
                                    Privacy
                                </a>
                           <br></br>
                                <a href="#" title="Cookies">
                                    Cookies
                                </a>
                           <br></br>
                                <a href="#" title="Licenses">
                                    Licenses
                                </a>
                           <br></br>
                                <a href="#" title="Cookies">
                                    Contact
                                </a>
                            
                        </ul>
                    </section>
                </div>
                <div class="footer-bottom">
                    <small>© My Company Ltd. <span id="year"></span>, All rights reserved</small>
                    <span class='social-links'>
                        <a href="#" title="Instagram">
                            <img src={insta} alt='Instagram'/>                       
                        </a>
                        <a href="#" title="Linkedin">
                            <img src={linkedin} alt='Linkedin'/>
                        </a>
                        <a href="#" title="Twitter">
                            <img src={twitter} alt='Twitter'/>
                        </a>
                        <a href="#" title="Youtube">
                            <img src={youtube} alt='YouTube'/>
                        </a>
                        <a href="#" title="GitHub">
                            <img src={github} alt='GitHub'/>
                        </a>
                    </span>
                </div>
            </div>
        </footer> */}
    
    </div>
  )
}
