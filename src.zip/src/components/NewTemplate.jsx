import React from 'react'
import "../css/newtemplate.css"
import img1 from "../css/4129901.webp"
import { TemplateDate } from './TemplateData'
import { Link } from 'react-router-dom'
import { useState,useEffect } from 'react'
import pick from "../components/asserts/Resume folder-bro.svg"
import fill from "../components/asserts/Resume-pana.svg"
import edit from "../components/asserts/Resume-amico.svg"
import Footer from '../Header/Footer'
export default function NewTemplate() {
    
    const Token = localStorage.getItem('token') == null
    const username = localStorage.getItem('username')
    const handleClick=()=>{
        if(Token){
          navigate("/");
        }
        else{
          navigate("/create");
        }
      }
      const handleLogout =() =>{
        localStorage.clear();
        navigate("/home")
      }

      const [isVisible, setIsVisible] = useState(false);
      const [isVisibletemp, setIsVisibletemp] = useState(false);

      useEffect(() => {
        const handleScroll = () => {
          const scrollY = window.scrollY;
          const triggerPoint = 400; // Change this value as needed
          const triggerPointtemp = 900;
          if (scrollY > triggerPoint && scrollY < triggerPointtemp) {
            setIsVisible(true);
          } 
          else if(scrollY>triggerPointtemp && scrollY< 3000){
            // setIsVisible(true);
            setIsVisibletemp(true);
          }
          else {
            setIsVisible(false);
            setIsVisibletemp(false);
          }
        };
    
        // Add a scroll event listener when the component mounts
        window.addEventListener('scroll', handleScroll);
    
        // Clean up the event listener when the component unmounts
        return () => {
          window.removeEventListener('scroll', handleScroll);
        };
      }, []);
  return (
    <div className='newtemplate'>
        <div>
      

<div className='home_navbar' style={{position:"absolute",top:"0px"}}>
  <div className='home_logo'>RESUME FUSION</div>
  <div className='home_menu'>
    
  <Link to="/" class='menu_item'>HOME</Link>
    <Link to="" class='menu_item'>ABOUT</Link>
    <Link to={`/save/${username}`} class='menu_item'>SAVED TEMPLATES</Link>
    {Token ?(
<div>

      <Link to="/login" class='menu_item'>LOGIN</Link>
      </div>
    ):(
      <div>
  <Link to="/" onClick={handleLogout}class='menu_item'>LOGOUT</Link>
  </div>
    )}


  </div>
</div>
          <svg id="wave" style={{transform: 'rotate(180deg)', transition: '0.3s' }} viewBox="0 0 1440 490" version="1.1" xmlns="http://www.w3.org/2000/svg">
      <defs>
        <linearGradient id="sw-gradient-0" x1="0" x2="0" y1="1" y2="0">
          <stop stopColor="rgba(62, 90.31, 243, 1)" offset="0%" />
          <stop stopColor="rgba(255, 11, 239.569, 1)" offset="100%" />
        </linearGradient>
      </defs>
      <path className="wave1"style={{ zIndex:"-99px",transform: 'translate(0, 0px)', opacity: 1 }} fill="url(#sw-gradient-0)" d="M0,196L40,163.3C80,131,160,65,240,81.7C320,98,400,196,480,236.8C560,278,640,261,720,236.8C800,212,880,180,960,155.2C1040,131,1120,114,1200,114.3C1280,114,1360,131,1440,171.5C1520,212,1600,278,1680,285.8C1760,294,1840,245,1920,212.3C2000,180,2080,163,2160,171.5C2240,180,2320,212,2400,228.7C2480,245,2560,245,2640,236.8C2720,229,2800,212,2880,212.3C2960,212,3040,229,3120,228.7C3200,229,3280,212,3360,187.8C3440,163,3520,131,3600,155.2C3680,180,3760,261,3840,269.5C3920,278,4000,212,4080,155.2C4160,98,4240,49,4320,24.5C4400,0,4480,0,4560,40.8C4640,82,4720,163,4800,220.5C4880,278,4960,310,5040,302.2C5120,294,5200,245,5280,187.8C5360,131,5440,65,5520,106.2C5600,147,5680,294,5720,367.5L5760,441L5760,490L5720,490C5680,490,5600,490,5520,490C5440,490,5360,490,5280,490C5200,490,5120,490,5040,490C4960,490,4880,490,4800,490C4720,490,4640,490,4560,490C4480,490,4400,490,4320,490C4240,490,4160,490,4080,490C4000,490,3920,490,3840,490C3760,490,3680,490,3600,490C3520,490,3440,490,3360,490C3280,490,3200,490,3120,490C3040,490,2960,490,2880,490C2800,490,2720,490,2640,490C2560,490,2480,490,2400,490C2320,490,2240,490,2160,490C2080,490,2000,490,1920,490C1840,490,1760,490,1680,490C1600,490,1520,490,1440,490C1360,490,1280,490,1200,490C1120,490,1040,490,960,490C880,490,800,490,720,490C640,490,560,490,480,490C400,490,320,490,240,490C160,490,80,490,40,490L0,490Z">

      </path>
      <defs>
        <linearGradient id="sw-gradient-1" x1="0" x2="0" y1="1" y2="0">
          <stop stopColor="rgba(62, 96.442, 243, 1)" offset="0%" />
          <stop stopColor="rgba(255, 11, 239.57, 1)" offset="100%" />
        </linearGradient>
      </defs>
      <path className="wave" style={{ zIndex:"-999px",transform: 'translate(0, 50px)', opacity: 0.9 }} fill="url(#sw-gradient-1)" d="M0,196L40,204.2C80,212,160,229,240,245C320,261,400,278,480,253.2C560,229,640,163,720,163.3C800,163,880,229,960,245C1040,261,1120,229,1200,212.3C1280,196,1360,196,1440,163.3C1520,131,1600,65,1680,89.8C1760,114,1840,229,1920,245C2000,261,2080,180,2160,196C2240,212,2320,327,2400,318.5C2480,310,2560,180,2640,155.2C2720,131,2800,212,2880,204.2C2960,196,3040,98,3120,122.5C3200,147,3280,294,3360,294C3440,294,3520,147,3600,98C3680,49,3760,98,3840,130.7C3920,163,4000,180,4080,212.3C4160,245,4240,294,4320,326.7C4400,359,4480,376,4560,343C4640,310,4720,229,4800,212.3C4880,196,4960,245,5040,277.7C5120,310,5200,327,5280,310.3C5360,294,5440,245,5520,245C5600,245,5680,294,5720,318.5L5760,343L5760,490L5720,490C5680,490,5600,490,5520,490C5440,490,5360,490,5280,490C5200,490,5120,490,5040,490C4960,490,4880,490,4800,490C4720,490,4640,490,4560,490C4480,490,4400,490,4320,490C4240,490,4160,490,4080,490C4000,490,3920,490,3840,490C3760,490,3680,490,3600,490C3520,490,3440,490,3360,490C3280,490,3200,490,3120,490C3040,490,2960,490,2880,490C2800,490,2720,490,2640,490C2560,490,2480,490,2400,490C2320,490,2240,490,2160,490C2080,490,2000,490,1920,490C1840,490,1760,490,1680,490C1600,490,1520,490,1440,490C1360,490,1280,490,1200,490C1120,490,1040,490,960,490C880,490,800,490,720,490C640,490,560,490,480,490C400,490,320,490,240,490C160,490,80,490,40,490L0,490Z"></path>
    </svg>
    {/* <div class="lineup">
      <h3 class="new_temp_animate_charcter" >CREATE TEMPLATE</h3>
    </div> */}
    <div className='wave1'>

<div className='csec1'style={{top:"-200px",fontSize:"50px"}}>
        CHOOSE YOUR<pre> </pre><h4>RESUME TEMPLATE</h4>
        {/* <br></br> */}
      </div>
    </div>
</div>
   
      <br></br>
     
    <section>
    <div class="square-wrapper">
    <div>
      <div className={`animated ${isVisible ? 'fadeIn' : 'fadeOut'}`}>
        <div className='csec1' style={{fontSize:"45px"}}>HOW TO<pre> </pre><h4 style={{color:"violet"}}>CREATE RESUME</h4><pre> </pre> TEMPLATE</div>
        <div className='image-container-template1'>
      <div className='image-container'>
        <img src={pick} className='image-template1'></img>
        <div className='textcontent'>SELECT A  TEMPLATE</div>
      </div>
      <div className='image-container'>
        <img src={fill} className='image-template1'></img>
        <div className='textcontent'>FILL OUT EACH SECTION</div>
      </div>
      <div className='image-container'>
        <img src={edit} className='image-template1'></img>
        <div className='textcontent'>CUSTOMIZE TO FIT YOUR JOB</div>
        </div>
      </div>
      </div>
    </div>
  {/* <div class={`${isVisible ? 'square square-transition':'square1 square-transition'}`}style={{ display: isVisible ? 'block' : 'none' }}></div> */}
</div>
</section>
      <br></br>
      <br></br>
      <section>
    {/* <div class="row">
  <div class="column">
    <img src={img1}/>
    <img src={img1}/>
    <img src={img1}/>
    <img src={img1}/>
    <img src={img1}/>
    <img src={img1}/>
    <img src={img1}/>
    
  </div>
  <div class="column">
    <img src={img1}/>
    <img src={img1}/>
    <img src={img1}/>
    <img src={img1}/>
    <img src={img1}/>
    <img src={img1}/>
    <img src={img1}/>
   
  </div>
  <div class="column">
    <img src={img1}/>
    <img src={img1}/>
    <img src={img1}/>
    <img src={img1}/>
    <img src={img1}/>
    <img src={img1}/>
    <img src={img1}/>
   
  </div>
  <div class="column">
  
  </div>
</div> */}
 <div className={`animated ${isVisibletemp ? 'fadeIn' : 'fadeOut'}`}>
<div className='image-container-template '>
{TemplateDate.map((template)=>(
  <Link to={`/form/${template.tid}`}>
     <img src= {template.Image} className='image-template'>
        
     </img>
     {/* <div class="middle">
    <div class="text">John Doe</div>
  </div> */}
  </Link>

))

}
</div>
</div>
    </section>


<Footer/>
</div>
  )
}
