import React, { useState } from 'react';
import { Outlet, Navigate } from 'react-router-dom';

export const Adminauth = () => {

    const Token = localStorage.getItem('token') !== null;
    const Role =  localStorage.getItem('ROLE') === "ADMIN";

    return (

        Token && Role ? <Outlet /> : <Navigate to='/login' />
    )
};