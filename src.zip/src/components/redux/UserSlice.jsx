import { createSlice } from "@reduxjs/toolkit";

export const UserSlice = createSlice({
    name: "user",
    initialState: {
        user: null,
        item: []
    },
    reducers: {
        login: (state, action) => {
            state.user = action.payload;
        },
        logout: (state) => {
            state.user = null;
        },
        saveTemp: (state, action) => {
            const newItem = action.payload;
            state.item.push({...newItem})
            // const existingItem = state.items.find(item => item.pid === newItem.pid);
      
            // if (existingItem) {
            //   existingItem.quantity += 1;
            // } else {
            //   state.items.push({ ...newItem, quantity: 1 });
            // }
          }
    }
});

export const { login, logout,saveTemp } = UserSlice.actions;
export const selectUser = (state) => state.user.user;
export const selectItem = (state) => state.user.item;
export default UserSlice;