import React, { useState, useEffect } from 'react';
import '../css/YourStylesheet.css'; // Import your CSS file
import { ReactDOM } from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom'
import axios from 'axios';
import { useDispatch } from 'react-redux';
import Popup from './popup/Popup';
import { login } from './redux/UserSlice';
import { loginform } from './Service/Api';
import { useUser } from './context/userContext';
import { register } from './Service/Api';
const Newlogin = () => {
  const [isSignIn, setIsSignIn] = useState(true);
  const[username,setUser] = useState([]);
  const[password,setPassword] = useState([]);
  const[email,setemail] = useState([]);

  useEffect(() => {
    setTimeout(() => {
      setIsSignIn(true);
    }, 200);
  }, []);

  const toggle = () => {
    setIsSignIn(!isSignIn);
  };
  const dispatch = useDispatch();
    const {id} = useParams();
  
    const { login: userLogin} = useUser();
    
    const navigate = useNavigate();
    const [formData, setFormData] = useState({
        email: '',
        password: '',
    });
    const [isPopupVisible, setPopupVisible] = useState(false);
    const [message, setMessage] = useState({
        type: '',
        content: '',
        url: '',
        btn: ''
    });



    const eventHandler = (e) => {
        const { name, value } = e.target;
        setFormData({
            ...formData,
            [name]: value,
        });
    };
    const showMessage = (type, content, url = '', btn = 'Got it') => {
      setMessage({ type, content, url, btn });
      setPopupVisible(true);
  };
  const handlePaste = (e) => {
    e.preventDefault();
    showMessage('error', 'Restricted action');
};

const handleGotItClick = () => {
    if (message.url) {
        navigate(message.url);
    }
    setPopupVisible(false);
};

  

const submitLoginForm = async(e) => {
  e.preventDefault();
  console.log("login");
  const formValues = Object.values(formData);
  if (!formValues.some((value) => !value)) {
    const res =  await loginform(formData)
    console.log(res.data);
    localStorage.setItem('token',res.data.token)
    localStorage.setItem('ROLE',res.data.role)
     
    if(res.status=='200'&& res.data.role=='ADMIN'){
      localStorage.setItem('username',formData.email);
      showMessage('success', 'Login successful!', '/Admin');
      userLogin();
      dispatch(login({username:formData.email}));
    }
    else if(res.status=='200'&& res.data.role=='USER'){
localStorage.setItem('username',formData.email);
      showMessage('success', 'Login successful!', '/');
      userLogin();
      dispatch(login({username:formData.email}));
    }
    else{
      <div>WRONG PASSWORD</div>
    }
      // navigate('/dashboard')
  } else {
      showMessage('error', 'Please fill in all fields');
  }
 
};
const handleSubmit = async (e) => {
  e.preventDefault();
  localStorage.clear();
  // const res = await axios.post('/signup/post',{username,password,email,dateofbirth,yrofstyding,department})
  // const rese = await axios.post('/post',{username,password})
  await register({username,email,password})
                        .then((res)=>console.log(res))
                       .catch((err)=>console.log(err));
                       setIsSignIn(!isSignIn);
 
  // console.log({username,password,email,dateofbirth,yrofstyding,department,phoneno})
}
  return (
    <div id="containerpage" className={`containerpage ${isSignIn ? 'sign-in' : 'sign-up'}`}>
      <div className="row">
        <div className="col align-items-center flex-col sign-up">
          <div className="form-wrapper align-items-center">
            <div className="form sign-up">
              <div className="input-group">
                <i className='bx bxs-user'></i>
                <input type="text" placeholder="Username" name="username" onChange={e=>setUser(e.target.value)} required />
              </div>
              <div className="input-group">
                <i className='bx bx-mail-send'></i>
                <input type="email" placeholder="Email" name="email" onChange={e=>setemail(e.target.value)} required />
              </div>
              <div className="input-group">
                <i className='bx bxs-lock-alt'></i>
                <input type="password" placeholder="Password" name="password" onChange={e=>setPassword(e.target.value)} required />
              </div>
              <div className="input-group">
                <i className='bx bxs-lock-alt'></i>
                <input type="password" placeholder="Confirm password" name="password" onChange={e=>setPassword(e.target.value)} required />
              </div>
              <button onClick={handleSubmit}>
                Sign up
              </button>
              <p>
                <span>
                  Already have an account?
                </span>
                <b onClick={toggle} className="pointer">
                  Sign in here
                </b>
              </p>
            </div>
          </div>
        </div>

        <div className="col align-items-center flex-col sign-in">
          <div className="form-wrapper align-items-center">
            <div className="form sign-in">
              <div className="input-group">
                <i className='bx bxs-user'></i>
                <input type="text" name="email" id='username' placeholder='Username'value={formData.email} onChange={eventHandler}  />
              </div>
              <div className="input-group">
                <i className='bx bxs-lock-alt'></i>
                <input type="password" name="password" id='password'placeholder='Password' value={formData.password} onChange={eventHandler} />
              </div>
              <button onClick={submitLoginForm}>
                Log In
              </button>
              <p>
                <b>
                  Forgot password?
                </b>
              </p>
              <p>
                <span>
                  Don't have an account?
                </span>
                <b onClick={toggle} className="pointer">
                  Sign up here
                </b>
              </p>
            </div>
          </div>
          <div className="form-wrapper">
            {/* Additional content for sign-in */}
          </div>
        </div>
      </div>

      <div className="row content-row">
        <div className="col align-items-center flex-col">
          <div className={`${isSignIn ? 'textlogin-signin' : 'textlogin-signup'}`}>
           
              {isSignIn ? 'Welcome' : 'Join with us'}
           
          </div>
          <div className={`img ${isSignIn ? 'sign-in' : 'sign-up'}`}>
            {/* Add image content here */}
          </div>
        </div>
       </div>
       {isPopupVisible && <Popup message={message} togglePopup={() => setPopupVisible(false)} handleGotItClick={handleGotItClick} />}
     </div>
  );
};

export default Newlogin;
