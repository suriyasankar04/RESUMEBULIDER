import React from 'react'
import { showTemplate } from './Service/Api';
import  { useEffect, useState } from 'react'
import { Link, useParams } from 'react-router-dom';
import Temp1 from './Template/temp1';
import { useNavigate } from 'react-router-dom';
import { useSelector, useDispatch } from 'react-redux';
import { selectItem } from './redux/UserSlice';
import "../css/SaveTemplate.css"
import Footer from '../Header/Footer';
export default function SaveTemplate() {
  // const userItems = useSelector(state => state.user.items);
  const userItems = useSelector(state=>state.user.item);
  const[game,setGame]= useState([]);
  const navigate = useNavigate();
  const dispatch = useDispatch();
  // const[id,setId]=useState([]);
  const {id} = useParams();
  const Token = localStorage.getItem('token') == null
  const fetchProducts = async () => {
    try {
        const response = await showTemplate(id)
        setGame(response.data);
        console.log(response.data);
      }
      
      catch (error) {
        console.log(error);
      }
    }
    
    
    const handleEdit = async() =>{
      const response = await showTemplate(id)
      setGame(response.data);
      console.log(response.data);
      // navigate( `/temp/edit/1`)
    }
    useEffect(() => {
      fetchProducts();
    console.log(game.data)
}, [])
const handleClick=()=>{
  if(!Token){
    navigate("/create");
  }
  else{
    navigate("/login");
  }
}
const handleLogout =() =>{
  localStorage.clear();
  navigate("/home")
}
      
  return (
 <div style={{background:"white"}}>
  <div class='hero-sectionsave'>
<div className='home_navbar'>
  <div className='home_logo'>RESUME FUSION</div>
  <div className='home_menu'>
    
  <Link to="/" class='menu_item' style={{color:"white"}}>HOME</Link>
    <Link to="" class='menu_item'style={{color:"white"}}>ABOUT</Link>
    {Token ?(
<div>

      <Link to="/login" class='menu_item'style={{color:"white"}}>LOGIN</Link>
      </div>
    ):(
      <div>
  <Link to="/" onClick={handleLogout}class='menu_item'style={{color:"white"}}>LOGOUT</Link>
  </div>
    )}


  </div>
</div>
       <div class='hero-text'>
         <h1 className='hero-sec'>YOUR SAVED TEMPLATES</h1>
         <p className='hero-sec'>Build a professional resume</p>
         <button className='btn-3' onClick={handleClick}><span>
          CREATE
          </span>
          </button>
       </div>
     
</div>
  {game.length ===0?(
    <div className='tempmiddle'>
      
      <p>NO SAVED TEMPLATES</p>
    </div>
  ):(
    <div>
   <button style={{width:"30px",height:"30px"}}onClick={handleEdit}>EDIT</button>
   <div className='imgtemp'>
        

   {/* <Temp1 formData={game} /> */}
   {game.map((item,index)=>
   {
    return(
      <>
      <Link to={`/temp/edit/${item.tid}`} style={{position:"relative",width:"30%" }}>
      <img className="imgs"src={item.imageData} alt='img'/>
      
      
      </Link>
      </>
      )
      
    }
    )
  }
   
  
   </div>
</div>

  )
  }
    <Footer/>
</div>
    
)
  }