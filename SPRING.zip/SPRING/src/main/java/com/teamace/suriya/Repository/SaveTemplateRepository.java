package com.teamace.suriya.Repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.teamace.suriya.Model.SaveTemplate;
import com.teamace.suriya.Model.User;

import jakarta.transaction.Transactional;

public interface SaveTemplateRepository extends JpaRepository<SaveTemplate,Long>{

	List<SaveTemplate>findByEmail(String email);

    @Transactional
    public void deleteAllByTid(Long tid);

    @Transactional
    public Optional<SaveTemplate>findByTid(Long tid);
	
    @Transactional
    SaveTemplate findBytid(Long tid);
}
