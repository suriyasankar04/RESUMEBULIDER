package com.teamace.suriya.Model.enumerate;

public enum Role {
	USER,
	
	ADMIN

}
