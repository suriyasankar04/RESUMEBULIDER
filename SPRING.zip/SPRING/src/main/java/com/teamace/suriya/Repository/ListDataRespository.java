package com.teamace.suriya.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.teamace.suriya.Model.ListData;
import java.util.List;


public interface ListDataRespository extends JpaRepository<ListData,Long>{
   ListData findByPid(Long pid);
  
}
