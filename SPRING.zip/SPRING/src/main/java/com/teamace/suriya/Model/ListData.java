package com.teamace.suriya.Model;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;

import java.util.ArrayList;

import jakarta.persistence.Entity;
import lombok.NoArgsConstructor;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name="_data")
public class ListData {
    
    	@Id
	 @GeneratedValue(strategy=GenerationType.IDENTITY)
	private Long pid;
	private String username;
	private String email;
	private String password;
	private ArrayList<String>feedback;
}
