package com.teamace.suriya.dto.response;

import java.util.ArrayList;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ListDataResponse {  
    private Long pid;
	private String username;
	private String email;
	private String password;
    private ArrayList<String>feedback;
}
