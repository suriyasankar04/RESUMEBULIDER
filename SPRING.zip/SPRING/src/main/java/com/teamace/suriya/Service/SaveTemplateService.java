package com.teamace.suriya.Service;

import java.io.IOException;
import java.util.List;
import java.util.Optional;


import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.teamace.suriya.Model.SaveTemplate;
import com.teamace.suriya.Model.Template;
import com.teamace.suriya.Model.enumerate.Role;
import com.teamace.suriya.Repository.SaveTemplateRepository;

import com.teamace.suriya.dto.request.SaveTemplateRequest;
import com.teamace.suriya.dto.request.TemplateRequest;

import jakarta.persistence.EntityNotFoundException;
import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class SaveTemplateService {
	
	private final SaveTemplateRepository saveTemplateRepository;

	
	public boolean savepost(SaveTemplateRequest request) throws IOException {
		
	
			
	    var user = SaveTemplate.builder()
	    		.sid(request.getSid())
	    		.email(request.getEmail())
	            .tid(request.getTid())
	            .firstname(request.getFirstname())
	            .lastname(request.getLastname())
	            .roles(request.getRoles())
	        	.language1(request.getLanguage1())
	        	.language2(request.getLanguage2())
	        	.skill1(request.getSkill1())
	        	.skill2(request.getSkill2())
	        	.skill3(request.getSkill3())
	        	.date1(request.getDate1())
	        	.date2(request.getDate2())
	        	.date3(request.getDate3())
	        	.des1(request.getDes1())
	        	.des2(request.getDes2())
	        	.des3(request.getDes3())
	        	.job1(request.getJob1())
	        	.job2(request.getJob2())
	        	.job3(request.getJob3())
	        	.education(request.getEducation())
				.imageData(request.getImageData())
	            .role(Role.USER)
	            .build();
	    saveTemplateRepository.save(user);
//	    var jwtToken = jwtservice.generateToken(user);
	    
		return true;
	}
	public boolean updateProduct(SaveTemplateRequest request, Long tid) {
		SaveTemplate product = saveTemplateRepository.findBytid(tid);

	        if (product != null) {
	            product.setSid(request.getSid());  
	            product.setFirstname(request.getFirstname());
	            product.setLastname(request.getLastname());
				product.setTid(request.getTid());
	            product.setRoles(request.getRoles());
	            product.setLanguage1(request.getLanguage1());
	            product.setLanguage2(request.getLanguage2());
	            product.setSkill1(request.getSkill1());
	            product.setSkill2(request.getSkill2());
	            product.setSkill3(request.getSkill3());
	            product.setDate1(request.getDate1());
	            product.setDate2(request.getDate2());
	            product.setDate3(request.getDate3());
	            product.setDes1(request.getDes1());
	            product.setDes2(request.getDes2());
	            product.setDes3(request.getDes3());
	            product.setJob1(request.getJob1());
	            product.setJob2(request.getJob2());
	            product.setJob3(request.getJob3());
	            product.setEducation(request.getEducation());
	     
	            saveTemplateRepository.save(product);

	            return true;
	        } else {
	            throw new EntityNotFoundException("Product with pid " + tid + " not found");
	        }
	} 
	 public List<SaveTemplate> saveget() {
	        List<SaveTemplate> productList = saveTemplateRepository.findAll();

	        return productList;
	    }
	public List<SaveTemplate> savegetbyid(String email) {
		List<SaveTemplate> prolist = saveTemplateRepository.findByEmail(email);
		return prolist;
	}
    public boolean delete(Long tid) {
         saveTemplateRepository.deleteAllByTid(tid);
		 return true;
		}
		public Optional<SaveTemplate> getTemplateData(Long tid) {
			Optional<SaveTemplate> product = saveTemplateRepository.findByTid(tid);
			return product;
			
		}
		public boolean deletebyid(Long sid) {
		saveTemplateRepository.deleteById(sid);
		return true;
	}
	
}
   
