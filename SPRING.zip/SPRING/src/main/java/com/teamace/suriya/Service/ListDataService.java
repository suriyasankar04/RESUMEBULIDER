package com.teamace.suriya.Service;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.teamace.suriya.Model.ListData;
import com.teamace.suriya.Repository.ListDataRespository;
import com.teamace.suriya.dto.request.ListDataRequest;


import jakarta.persistence.EntityNotFoundException;
import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class ListDataService {

    private final ListDataRespository listDataRepository;

    public boolean registerdata(List<ListDataRequest> request) {
boolean allsaved = request.stream().allMatch(res->{
    var data = ListData.builder()
                .username(res.getUsername())
                .email(res.getEmail())
                .password(res.getPassword())
                .feedback(res.getFeedback())
                .build();
    
            listDataRepository.save(data);
    return true;
}
);
return allsaved;
}
    

    public List<ListData> getAllData() {

        List<ListData> data = listDataRepository.findAll();
        return data;
    }

    public boolean updatedata(List<ListDataRequest> request, Long pid) {
            ListData data = listDataRepository.findByPid(pid);
            boolean allsaved = request.stream().allMatch(res->{
            if(data!=null){
                   data.setUsername(res.getUsername());
                   data.setEmail(res.getEmail());
                   data.setPassword(res.getPassword());
                data.setFeedback(res.getFeedback());
                   listDataRepository.save(data);
                   return true;
            }
            else {
	            throw new EntityNotFoundException("Data with pid " + pid + " not found");
	        }
        }
            );
            return allsaved;

    }

   

    
    
}
