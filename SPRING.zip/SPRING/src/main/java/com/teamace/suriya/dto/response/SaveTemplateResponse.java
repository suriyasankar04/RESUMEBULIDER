package com.teamace.suriya.dto.response;

public class SaveTemplateResponse {

}
