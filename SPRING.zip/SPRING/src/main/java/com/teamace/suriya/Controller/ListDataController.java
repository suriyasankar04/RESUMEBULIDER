package com.teamace.suriya.Controller;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.teamace.suriya.Model.ListData;
import com.teamace.suriya.Model.Template;
import com.teamace.suriya.Service.ListDataService;
import com.teamace.suriya.dto.request.ListDataRequest;
import com.teamace.suriya.dto.request.TemplateRequest;

import lombok.RequiredArgsConstructor;

@RestController
@RequestMapping("/api/v1/listdata")	
@CrossOrigin("*")
@RequiredArgsConstructor
public class ListDataController {
    
private final ListDataService listDataService;

@PostMapping("/register")
	  public ResponseEntity<String> register(
	      @RequestBody List<ListDataRequest> request
	  ) {
	      boolean isSaved = listDataService.registerdata(request);
	        return isSaved ? ResponseEntity.status(201).body("Data added successfully!")
	                : ResponseEntity.badRequest().build();
//	    return ResponseEntity.ok(templateService.register(request));
	  }
	
	@GetMapping("/get")
	 public ResponseEntity<List<ListData>> getAllData() {
        List<ListData> listdata = listDataService.getAllData();
        return !listdata.isEmpty() ? ResponseEntity.status(200).body(listdata)
                : ResponseEntity.noContent().build();
    }

	  @PutMapping("/edit/{pid}")
	    public ResponseEntity<String> updatedata(@RequestBody List<ListDataRequest> request, @PathVariable Long pid) {
	        boolean isUpdate = listDataService.updatedata(request, pid);
	        return isUpdate ? ResponseEntity.status(201).body("Update Successfull") 
	        		: ResponseEntity.notFound().build();
	    }

}
